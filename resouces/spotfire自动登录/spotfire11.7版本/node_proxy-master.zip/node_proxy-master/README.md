# node_proxy
跨域代理, 提前安装 node, express

# 初始化package.josn
    npm init

# 下载依赖 http-proxy-middleware
    cnpm install --save-dev http-proxy-middleware

# 运行
    node server.js
    http://localhost:8082/demo.html